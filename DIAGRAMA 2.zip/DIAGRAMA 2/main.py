from flask import Flask, render_template, request, redirect, url_for
from maquinariaAD import clsRegistroMaquinaria, iniciar_jornada, finalizar_jornada, obtener_registro_activo

app = Flask(__name__)

# --- 1. PANTALLA CHECK-IN (Inicio de Jornada) ---
@app.route("/maquinaria/checkin")
def checkin_maquinaria():
    return render_template("checkin_maq.html")

@app.route("/guardar_checkin", methods=["POST"])
def guardar_checkin():
    try:
        objRegistro = clsRegistroMaquinaria(
            request.form["maquina"],
            request.form["zona"],
            request.form["combustible_inicial"],
            request.form["horas_estimadas"]
        )
        # Inicia la jornada y nos devuelve el ID de ese viaje
        id_viaje = iniciar_jornada(objRegistro)
        if id_viaje:
             # Redirigimos a la pantalla de monitoreo de ESE viaje en específico
             return redirect(url_for('monitoreo_activo', id_registro=id_viaje))
            
        return "Error al iniciar la jornada."
    except Exception as e:
        return "Excepción capturada: " + repr(e)

# --- 2. PANTALLA CHECK-OUT (Monitoreo y Fin de Jornada) ---
@app.route("/maquinaria/activo/<int:id_registro>")
def monitoreo_activo(id_registro):
    # Buscamos los datos de la máquina que está en ruta
    registro = obtener_registro_activo(id_registro)
    if registro:
        return render_template("checkout_maq.html", registro=registro)
    return "Registro no encontrado."

@app.route("/guardar_checkout/<int:id_registro>", methods=["POST"])
def guardar_checkout(id_registro):
    try:
        # Verificamos si se presionó el botón de Avería o el de Finalizar
        accion = request.form.get("accion")
        
        if accion == "averia":
            estado = "AVERIADO"
            observacion_falla = request.form.get("observacion_falla", "")
            finalizar_jornada(id_registro, None, None, None, estado, observacion_falla)
        else:
            estado = "LIBRE"
            combustible_final = request.form["combustible_final"]
            horas_reales = request.form["horas_reales"]
            motivo_retraso = request.form.get("motivo_retraso", "")
            finalizar_jornada(id_registro, combustible_final, horas_reales, motivo_retraso, estado, None)
            
        return "¡Jornada finalizada / reportada con éxito! (Aquí iría la redirección a tu Dashboard)"
    except Exception as e:
        return "Excepción capturada: " + repr(e)

if __name__ == "__main__":
    app.run(debug=True)