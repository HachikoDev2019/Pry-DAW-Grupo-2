import pymysql.cursors

class clsRegistroMaquinaria:
    def __init__(self, p_maquina, p_zona, p_combustible_inicial, p_horas_estimadas):
        self.maquina = p_maquina
        self.zona = p_zona
        self.combustible_inicial = p_combustible_inicial
        self.horas_estimadas = p_horas_estimadas
        self.estado = "EN RUTA" # Estado inicial por defecto al hacer Check-In

def obtenerconexion():
    try:
        connection = pymysql.connect(host='localhost',
                                     user='root',
                                     password='',
                                     database='db_pomalca',
                                     cursorclass=pymysql.cursors.DictCursor)
        return connection
    except Exception as e:
        print("Error de conexión:", repr(e))
        return None
    
def iniciar_jornada(p_registro):
    try:
        conn = obtenerconexion()
        if conn:
            with conn:
                with conn.cursor() as cursor:
                    sql = """INSERT INTO registros_maquinaria 
                             (maquina, zona, estado, combustible_inicial, horas_estimadas) 
                             VALUES (%s, %s, %s, %s, %s)"""
                    cursor.execute(sql, (
                        p_registro.maquina, 
                        p_registro.zona, 
                        p_registro.estado, 
                        p_registro.combustible_inicial,
                        p_registro.horas_estimadas
                    ))
                    # Obtenemos el ID generado para mandarlo al Check-Out
                    registro_id = cursor.lastrowid 
                conn.commit()
            return registro_id
        return None
    except Exception as e:
        print("Error al insertar:", repr(e))
        return None

def obtener_registro_activo(id_registro):
    try:
        conn = obtenerconexion()
        if conn:
            with conn:
                with conn.cursor() as cursor:
                    sql = "SELECT * FROM registros_maquinaria WHERE id = %s"
                    cursor.execute(sql, (id_registro,))
                    return cursor.fetchone()
    except Exception as e:
        print("Error al obtener:", repr(e))
        return None

def finalizar_jornada(id_registro, combustible_final, horas_reales, motivo_retraso, estado, observacion_falla):
    try:
        conn = obtenerconexion()
        if conn:
            with conn:
                with conn.cursor() as cursor:
                    sql = """UPDATE registros_maquinaria 
                             SET estado = %s, combustible_final = %s, horas_reales = %s, 
                                 motivo_retraso = %s, observacion_falla = %s, fecha_fin = CURRENT_TIMESTAMP
                             WHERE id = %s"""
                    cursor.execute(sql, (
                        estado, combustible_final, horas_reales, motivo_retraso, observacion_falla, id_registro
                    ))
                conn.commit()
            return True
        return False
    except Exception as e:
        print("Error al actualizar:", repr(e))
        return False