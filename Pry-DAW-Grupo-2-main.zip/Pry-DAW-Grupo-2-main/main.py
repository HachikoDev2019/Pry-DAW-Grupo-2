from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from maquinariaAD import clsMaquinaria, insertar_maquinaria, listar_maquinarias
from solicitudAD import (clsSolicitud, insertar_solicitud, listar_mis_solicitudes, listar_todas_solicitudes, actualizar_solicitud)
from personalAD import clsPersonal, insertar_personal, verificar_credenciales, listar_personal, leer_personal_xDNI
from actividadAD import clsActividad, iniciar_actividad, listar_actividades_activas, obtener_actividad, finalizar_actividad

app = Flask(__name__)
app.secret_key = "pomalca_secret_key"

# ==========================================
# AUTHENTICATION
# ==========================================
@app.route("/", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        dni = request.form.get('dni', '').strip()
        pwd = request.form.get('password', '').strip()
        trabajador = verificar_credenciales(dni, pwd)
        if trabajador:
            session.update({
                'id_personal': trabajador['id_personal'],
                'nombres': trabajador['nombres'],
                'apellidos': trabajador['apellidos'],
                'tipo_usuario': trabajador['tipo_usuario']
            })
            return redirect(url_for('dashboard'))
        flash("Credenciales inválidas o usuario inactivo.", "error")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    if 'id_personal' not in session: return redirect(url_for('login'))
    return render_template("dashboard.html")

# ==========================================
# MAQUINARIA (Admin y Supervisor)
# ==========================================
@app.route("/registro_maquinaria")
def registro_maquinaria():
    if session.get('tipo_usuario') != 'Administrador':
        flash("Acceso denegado.", "error")
        return redirect(url_for('dashboard'))
    return render_template("maquinaria/registro_maquinaria.html")

@app.route("/mis_maquinarias")
def mis_maquinarias():
    if session.get('tipo_usuario') not in ['Administrador', 'Supervisor']:
        return redirect(url_for('dashboard'))
    return render_template("maquinaria/mis_maquinarias.html", maquinarias=listar_maquinarias())

# ==========================================
# SOLICITUDES (Trabajador y Admin)
# ==========================================
@app.route("/registrar_solicitud")
def registrar_solicitud():
    return render_template("solicitudes/registrar_solicitud.html")

@app.route("/guardar_solicitud", methods=["POST"])
def guardar_solicitud():
    nombre = f"{session.get('nombres')} {session.get('apellidos')}"
    solicitud = clsSolicitud(nombre, request.form["descripcion"], request.form["area"], request.form["prioridad"])
    insertar_solicitud(solicitud)
    return redirect(url_for("mis_solicitudes"))

@app.route("/mis_solicitudes")
def mis_solicitudes():
    solicitudes = listar_mis_solicitudes(f"{session.get('nombres')} {session.get('apellidos')}")
    return render_template("solicitudes/mis_solicitudes.html", solicitudes=solicitudes)

@app.route("/gestion_solicitudes")
def gestion_solicitudes():
    if session.get('tipo_usuario') != 'Administrador': return redirect(url_for('dashboard'))
    return render_template("solicitudes/gestion_solicitudes.html", 
                           solicitudes=listar_todas_solicitudes(request.args.get("estado"), request.args.get("area"), request.args.get("prioridad")))

@app.route("/actualizar_solicitud", methods=["POST"])
def actualizar_solicitud_estado():
    actualizar_solicitud(request.form["id_solicitud"], request.form["estado"], request.form["comentario"])
    return redirect(url_for("gestion_solicitudes"))

# ==========================================
# ACTIVIDAD MAQUINARIA (Todos)
# ==========================================
@app.route("/actividad_maquinaria")
def actividad_maquinaria():
    return render_template("actividad/listado.html", actividades=listar_actividades_activas())

@app.route("/actividad/checkin")
def checkin_actividad():
    maquinas = [m for m in listar_maquinarias() if m['estado'] == 'Operativo']
    return render_template("actividad/checkin.html", maquinas=maquinas)

@app.route("/guardar_checkin", methods=["POST"])
def guardar_checkin():
    actividad = clsActividad(request.form["maquina"], request.form["zona"], request.form["combustible_inicial"], request.form["horas_estimadas"])
    id_viaje = iniciar_actividad(actividad)
    return redirect(url_for("monitoreo_activo", id_actividad=id_viaje)) if id_viaje else redirect(url_for("checkin_actividad"))

@app.route("/actividad/activo/<int:id_actividad>")
def monitoreo_activo(id_actividad):
    return render_template("actividad/checkout.html", actividad=obtener_actividad(id_actividad))

@app.route("/guardar_checkout/<int:id_actividad>", methods=["POST"])
def guardar_checkout(id_actividad):
    accion = request.form.get("accion")
    if accion == "averia":
        finalizar_actividad(id_actividad, None, None, None, "AVERIADO", request.form.get("observacion_falla", ""))
    else:
        finalizar_actividad(id_actividad, request.form["combustible_final"], request.form["horas_reales"], request.form.get("motivo_retraso", ""), "FINALIZADO", None)
    return redirect(url_for("actividad_maquinaria"))

# ==========================================
# REGISTRO PERSONAL (Admin)
# ==========================================
@app.route("/registro")
def registro():
    if session.get('tipo_usuario') != 'Administrador': return redirect(url_for('dashboard'))
    return render_template("registro.html")

if __name__ == "__main__":
    app.run(debug=True)